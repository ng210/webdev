include('/ui/valuecontrol.js');

(function() {
	Ui.Button = function(id, config, el) {
		Ui.ValueControl.call(this, id, config, el);
		el.setAttribute('type', 'button');
	};
	Ui.Button.prototype = new Ui.ValueControl('button', {}, {});
	Ui.Control.Types['button'] = { ctor: Ui.Button, tag: 'INPUT' };

})();