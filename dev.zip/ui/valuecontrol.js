include('/ui/control.js');

(function() {
	// Abstract type for controls holding a single value
	Ui.ValueControl = function(id, template, el) {
		Ui.Control.call(this, id, template, el);
		this.isNumeric = false;
		this.parse = null;
		switch (template.dataType) {
			case Ui.Control.DataTypes.int:
				this.isNumeric = true;
				this.parse = parseInt;
				break;
			case Ui.Control.DataTypes.float:
				this.isNumeric = true;
				this.parse = parseFloat;
				break;
		}
		this.value = this.isNumeric ? (this.parse(template.value) || 0) : template.value;
	}
	Ui.ValueControl.prototype = new Ui.Control('valueCtrl', {}, {});
	Ui.ValueControl.prototype.validate = function() {
		return this.value >= this.min && this.value <= this.max;
	};
	Ui.ValueControl.prototype.registerHandler = function(event, handler, context) {
		if (['change'].indexOf(event) == -1) throw new Error('Event \''+ event +'\' not supported!');
		Ui.Control.registerHandler(this, event, handler, context);
	};
	Ui.Textbox.prototype.render = function(ctx) {
		Ui.Control.prototype.render.call(this, ctx);
		if (this.isNumeric) {
			this.element .setAttribute('min', this.min = this.parse(config.min) || 0);
			this.element.setAttribute('max', this.max = this.parse(config.max) || 100);
			this.element.setAttribute('step', this.step = this.parse(config.step) || 1);
		}
		this.element.onchange = Ui.Control.onevent;
		this.element.value = this.value;
	};

})();