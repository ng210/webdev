﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HealthState.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace HealthState.Controllers
{
    [Route("api/healthstate")]
    [ApiController]
    public class HealthStateController : ControllerBase
    {
        private ServerGroup _resources;
        public HealthStateController(IOptions<ServerGroup> settings)
        {
            _resources = settings.Value;
        }


        // GET api/servergroup
        [HttpGet]
        public ActionResult<string> Get()
        {
            return "1";
        }

        // GET api/servergroup/[id]
        [HttpGet("{id}")]
        public ActionResult<string> Get(string id)
        {
           return "2";
        }

        // GET api/servergroup/[sgid]/server[id]
        [HttpGet("{sgid}/{id}")]
        public ActionResult<string> Get(string sgid, string id)
        {
            return "3";
        }

        // GET api/servergroup/[sgid]/server[sid]/service/[id]
        [HttpGet("{sgid}/{sid}/{id}")]
        public ActionResult<string> Get(string sgid, string sid, string id)
        {
            return "4";
        }

        // POST api/values
        [HttpPost]
        public void Post([FromBody] string value)
        {
        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }
    }
}
