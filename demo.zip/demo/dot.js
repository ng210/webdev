(function() {

	function Dot() {
		this.pos = [2*Math.random()-1, 2*Math.random()-1];
		this.r = (0.75*Math.random() + 0.25)/100;
		this.mass = Dot.mass(this.r);
		var arg = 2 * Math.PI * Math.random();
		var r = 0;	//0.0001*Math.random();
		var vx = r*Math.cos(arg), vy = r*Math.sin(arg);
		this.v = [vx, vy];
		this.a = [0.0, 0.0];
		this.isAlive = true;
		this.constructor = Dot;
	}
	Dot.prototype.update = function(frame, dt) {
		this.pos[0] += this.v[0]*dt;
		this.pos[1] += this.v[1]*dt;
		this.v[0] += this.a[0]*dt;
		this.v[1] += this.a[1]*dt;
		this.a[0] = 0;
		this.a[1] = 0;
	};
	Dot.prototype.render = function(frame, ctx) {
		var r = ctx.canvas.width*this.r;
		var s = 2*r;
		var x = (this.pos[0] + 1.0) * ctx.canvas.width/2 - r;
		var y = (this.pos[1] + 1.0) * ctx.canvas.height/2 - r;
		ctx.fillRect(x, y, s, s);
	};
	Dot.prototype.toString = function() {
		return [
			'mass:     ' + (1000*this.mass).toFixed(4),
			'radius:   ' + this.r.toFixed(4),
			'position: ' + this.pos[0].toFixed(4)+' | '+this.pos[1].toFixed(4)
		].join();
	};
	
	Dot.radius = function(m) {
		return Math.pow(3*m/4/Math.PI, 1/3);
	};
	Dot.mass = function(r) {
		return 4*r*r*r*Math.PI/3;
	};
	
	public(Dot, 'Dot');

})();