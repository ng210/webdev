include('control.js');
// row/column based => list
// template for rows/cells selected by an optional data field
(function() {
	Ui.Grid = function(id, template) {
		Ui.Control.call(this, id, template);
		// set rows/columns array
		this.rowKeys = null;
		this.rows = {};
		this.columnKeys = null;
		this.columns = {};
		this.rowTemplates = template['row-templates'] || {};
		this.cellTemplates = template['cell-templates'] || {};
		this.templateSelector = template['template-selector'];
		this.dataSource = null;

		this.constructor = Ui.Grid;
	};
	Ui.Grid.base = Ui.Control.prototype;
	Ui.Grid.prototype = new Ui.Control('grid');
	Ui.Control.Types['grid'] = { ctor: Ui.Grid, tag: 'DIV' };

	Ui.Grid.prototype.buildRow = function(row, src) {
		// build a row from the given data source
		// using the selected template
		var ri = row.id;
		var tmplKey = (src[this.templateSelector] === '$key' ? row.name : src[this.templateSelector]) || 'default';
		var rowTmpl = this.rowTemplates[tmplKey];
		if (rowTmpl === undefined)
		this.columnKeys = null;
		if (typeof rowTmpl === 'object') {
			this.columnKeys = Object.keys(rowTmpl);
		} else {
			if (Array.isArray(src)) this.columnKeys = src.map( (v, ix) => ix );
			else if (typeof src === 'object') this.columnKeys = Object.keys(src);
			else {
				src = [src];
				this.columnKeys = [0];
			}
		}
		for (var ci=0; ci<this.columnKeys.length; ci++) {
			var key = this.columnKeys[ci];
			var col = this.columns[key];
			if (col == undefined) {
				col = { id: ci, name: key, cells: [], parent: this };
				this.columns[key] = col;
			}

			var tmpl = rowTmpl[key] ? rowTmpl[key] : this.cellTemplate;
			var dataField = tmpl['data-field'] || key;
			var cell = Ui.Control.create(this.id + '#' + ri + '#' + ci, tmpl);
			if (tmpl.label === true) cell.label = key;
			cell.dataBind(src, dataField);
			cell.row = row; cell.column = col;
			cell.parent = row;
			row.cells[ci] = row.cells[key] = cell;
			col.cells.push(cell);
		}
		return row;
	};
	Ui.Grid.prototype.build = function() {
	// create rows, columns and cells
		var src = this.dataSource;
		this.rowKeys = null;
		if (Array.isArray(src)) this.rowKeys = src.map( (v, ix) => ix );
		else if (typeof src === 'object') this.rowKeys = Object.keys(src);
		else throw new Error('Invalid data source!');
		for (var ri=0; ri<this.rowKeys.length; ri++) {
			var key = this.rowKeys[ri];
			var srcRow = this.dataSource[key];
			var row = { id: ri, name: key, cells:{}, parent: this };
			this.buildRow(row, srcRow);
			this.rows[key] = row;
		}
	};

	Ui.Grid.prototype.dataBind = function(obj) {
		Ui.Grid.base.dataBind.call(this, obj);
		this.build();
		Ui.Control.registerHandler.call(this);
	};
	Ui.Grid.prototype.getCell = function(ri, ci) {
		if (typeof ri === 'string') {
			var tokens = ri.split('#');
			ri = tokens[0];
			ci = tokens[1];
		}
		var row = this.rows[ri];
		return row ? row.cells[ci] : null;
	};
	Ui.Grid.prototype.render = function(ctx) {
		Ui.Grid.base.render.call(this, ctx);
		var table = document.createElement('TABLE');
		table.className = 'grid table';
		this.element.appendChild(table);
		for (var ri=0; ri<this.rowKeys.length; ri++) {
			var row = this.rows[this.rowKeys[ri]];
			var tr = document.createElement('TR');
			var rowClass = ri % 2 ? 'r0' : 'r1';
			tr.className = 'grid row ' + rowClass;
			for (var ci=0; ci<this.columnKeys.length; ci++) {
				var td = document.createElement('TD');
				var cellClass = rowClass + ' ' + (ci % 2 ? 'c0' : 'c1');
				td.className = 'grid cell ' + cellClass;
				var cell = row.cells[ci];
				cell.render({node: td});
				td.appendChild(cell.element);
				tr.appendChild(td);
			}
			table.appendChild(tr);
		}
	};
})();
