(function()	 {
	function Setting(demo, configKey) {
		var config = demo.config[configKey];
		this.id	= configKey;
		this.control =	config.control;
		this.trigger = [];

		switch (config.type) {
			case Settings.DataTypes.int:
				this.min = parseInt(config.min) || 0;
				this.max = parseInt(config.max) || 100;
				this.step = parseInt(config.step) || 1;
				this.value = parseInt(config.value) || 0;
				break;
			case Settings.DataTypes.float:
				this.min = parseFloat(config.min) || 0.0;
				this.max = parseFloat(config.max) || 1.0;
				this.step = parseFloat(config.step) || 0.1;
				this.value = parseFloat(config.value) || 0.0;
				break;
			default:
				this.value = config.value;
		}

		this.element = null;
		switch (this.control) {
			default:
			case Setting.ControlTypes.textbox:
				this.element = document.createElement('INPUT');
				this.element.setAttribute('type', 'text');
				this.element.setAttribute('size', 4);
				break;
			case Setting.ControlTypes.list:
				this.items = [];
				this.element = document.createElement('SELECT');
				for	(var i=0; i<config.items.length; i++)	{
					var configItem = config.items[i];
					var item = {};
					var	option = document.createElement("option");
					if (Array.isArray(config.items[i])) {
						item.key = configItem[0];
						item.value = configItem[1];						
					} else {
						item.key = item.value = configItem;
					}
					item.index = i;
					option.text = item.key;
					option.value = item.value;
					this.element.add(option);
					this.items.push(item);
				}
				break;
			case Setting.ControlTypes.slider:
				this.element = document.createElement('INPUT');
				this.element.setAttribute('type', 'range');
				this.element.setAttribute('min', this.min);
				this.element.setAttribute('max', this.max);
				this.element.setAttribute('step', this.step);
				break;
		}
		this.element.id = demo.id + '#' + this.id;
		this.element.className = ['settings value', demo.id, this.id, this.control].join(' ');
		this.element.onchange =	Setting.onchange;
		this.element.setting = this;

		this.constructor = Setting;
	}
	Setting.prototype.render = function() {

	};
	Setting.prototype.getValue = function()	{
		var	v =	0;
		switch (this.control) {
			default:
			case Setting.ControlTypes.slider:
			case Setting.ControlTypes.textbox:
				v =	this.element.value;
				break;
			case Setting.ControlTypes.list:
				var item = this.items[this.element.selectedIndex];
				v =	{ key: item.key, value: item.value, index:item.index };
				break;
		}
		return v;
	};
	Setting.prototype.setValue = function(v) {
		switch (this.control) {
			default:
			case Setting.ControlTypes.slider:
			case Setting.ControlTypes.textbox:
				this.element.value = v;
				break;
			case Setting.ControlTypes.list:
				// set by value
				this.element.selectedIndex = v;
				break;
		}
	};
	Setting.DataTypes = {
		int:	'int',
		float:	'float',
		string:	'string'
	};

	Setting.ControlTypes = {
		textbox:	'textbox',
		list:		'list',
		slider:		'slider'
	};
	
	Setting.onchange = function(e) {
		var	setting	= e.target.setting;
		setting.demo.onsettingchanged(setting);
	};

	var	DemoUI = {
		initialize:	function(node, demo) {
			while (node.children.length	> 0) {
				node.removeChild(node.children[0]);
			}
			demo.settings =	{};
			var	tab	= document.createElement('TABLE');
			tab.className =	'settings';
			var	tr = document.createElement('TR');
			var	td = document.createElement('TD');
			td.setAttribute('colspan', 2);
			td.className = 'settings header';
			td.innerHTML = '<b>' + demo.id + '</b>';
			tr.appendChild(td);
			tab.appendChild(tr);
			var	keys = Object.keys(demo.config);
			keys.forEach( key => {
				var	setting	= new Setting(demo, key);
				setting.setValue(demo.config[key].value	|| 0);
				setting.demo = demo;
				demo.settings[key] = setting;
				tr = document.createElement('TR');
				td = document.createElement('TD');
				td.className = 'settings label';
				td.innerHTML = key;
				tr.appendChild(td);
				td = document.createElement('TD');
				td.className = 'settings value';
				td.appendChild(setting.element);
				tr.appendChild(td);
				tab.appendChild(tr);
			});
			node.appendChild(tab);
			return settings;
		}
	};

	public(DemoUI, 'DemoUI');
})();