include('demo.js');
(function() {
    function TestUi(canvas) {
        this.id = 'Test-UI';
        this.canvas = canvas;
        this.config = {};
        this.constructor = TestUi;
    }
    TestUi.prototype = new Demo();
    TestUi.prototype.initialize = function() {
		Dbg.prln('TestUi initialize');
        this.ui.color.setItems(['red', 'green', 'blue']);
	};
    TestUi.prototype.processInputs = function() { throw new Error('Not implemented'); };
    TestUi.prototype.update = function(frame) {
    };
    TestUi.prototype.render = function(frame) {
    };
    
    TestUi.prototype.onchange = function(ctrl) {
        Dbg.prln('TestUi.onchange at ' + ctrl.id);
    };

    public(TestUi, 'TestUi');

})();