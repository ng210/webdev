include('/ui/valuecontrol.js');
(function() {

    Ui.DropDownList = function(id, config, el) {
        Ui.ValueControl.call(this, id, config, el);
        this.items = [];
        if (Array.isArray(config.items)) {
            for (var i=0; i<config.items.length; i++)	{
                var configItem = config.items[i];
                var item = {};
                var option = document.createElement("option");
                if (Array.isArray(config.items[i])) {
                    item.key = configItem[0];
                    item.value = configItem[1];						
                } else {
                    item.key = item.value = configItem;
                }
                item.index = i;
                option.text = item.key;
                option.value = item.value;
                this.element.add(option);
                this.items.push(item);
            }
            this.setValue(config.value);
            el.onchange = Ui.Control.onevent;
        }
        this.constructor = Ui.DropDownList;
    };
    Ui.DropDownList.prototype = new Ui.ValueControl('ddlist', {}, {});
    Ui.Control.Types['ddlist'] = { ctor: Ui.DropDownList, tag: 'SELECT' };

    Ui.DropDownList.prototype.getValue = function() {
        var item = this.items[this.element.selectedIndex];
        return { key: item.key, value: item.value, index:item.index };
    };
    Ui.DropDownList.prototype.setValue = function(v) {
        this.element.selectedIndex = v;
    };

})();
