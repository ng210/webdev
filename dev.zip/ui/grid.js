include('control.js');
(function() {
	Ui.Grid = function(id, config, el) {
		Ui.Control.call(this, id, el);
		this.rows = new Array(config.rows || 0);
		this.cols = new Array(config.cols || 0);
		this.dataSource = config.dataSource;
		this.rowTemplates = config['row-templates'];
		this.cellTemplate = config['cell-template'];
Dbg.prln('ctor: ' + this.rows);
		this.render();
		
		this.constructor = Ui.Grid;
	};
	Ui.Grid.prototype = new Ui.Control('grid', {}, {});
	Ui.Control.Types['grid'] = { ctor: Ui.Grid, tag: 'DIV' };
	
	Ui.Grid.prototype.render = function() {
		var table = document.createElement('TABLE');
		table.className = 'grid table';
		if (this.rowTemplates !== undefined) {
			
		}
		if (this.cellTemplate !== undefined) {
			for (var ri=0; ri<this.rows.length; ri++) {
				var tr = document.createElement('TR');
				tr.className = 'grid row ' + (ri % 2 ? 'even' : 'odd');
				var row = { id: ri, cells: {}, element: tr };
				for (var ci=0; ci<this.cols.length; ci++) {
					var ctrl = Ui.Control.create(this.id+'#'+ci+'#'+ri, this.cellTemplate);
Dbg.prln(ctrl.id + ' ' + ctrl.element.tagName):
					this.rows[ri].cells[ci] = ctrl;
					var td = document.createElement('TD');
					td.className = 'grid cell';
					td.appendChild(ctrl.element);
					tr.appendChild(td);
				}
				this.rows[ri] = row;
			}
		}
		throw new Error('Invalid or missing template!');
		
/*
		for (var i=0; i<config.rows; i++) {
			var tr = document.createElement('TR');
			tr.className = 'grid row ' + (i % 2 ? 'even' : 'odd');
			var row = { id: i, cells: {}, element: tr };
			for (var j=0; j<config.cols; j++) {
				var td = document.createElement('TD');
				td.className = 'grid cell';
				var ctrl = null;
				if (config.templates.cell !== undefined) {
					ctrl = Ui.Control.create(this.id+'#'+i+'#'+j, config.templates.cell);
					row.cells[key] = row.cells[j] = ctrl;
				} else if (config.templates.row !== undefined) {
					var key = Object.keys(config.templates.row)[j];
					var template = config.templates.row[key];
					ctrl = Ui.Control.create(this.id+'#r'+i+'c'+j, config.templates.row[key]);
					if (template.label !== false) {
						var label = document.createElement('SPAN');
						label.className = 'grid cell label';
						label.innerHTML = key;
						td.appendChild(label);
					}
					row.cells[key] = row.cells[j] = ctrl;
				}
				td.appendChild(ctrl.element);
				tr.appendChild(td);
				if (this.cols[j] === undefined) this.cols.push({ id: j, cells: [] });
				this.cols[j].cells.push(ctrl);
			}
			this.rows.push(row);
			table.appendChild(tr);
		}
*/
		this.element.appendChild(table);
	};
alert(2);
})();