(function() {
	var Ui = {};
	Ui.Control = function(id, template) {
		this.id = id;
		this.template = template;
		this.label = template.label;
		this.info = Ui.Control.Types[template.type];
		this.css = [];
		this.handlers = {};
		this.element = null;
		this.wrapper = null;
		this.constructor = Ui.Control;
	}
	//Ui.Control.prototype.bind = function(obj) { throw new Error('Not implemented!'); };
	Ui.Control.prototype.getValue = function() { return this.element.value; };
	Ui.Control.prototype.setValue = function(v) { this.element.value = v; };
	Ui.Control.prototype.render = function(ctx) {
		if (!this.element) {
			this.element = document.createElement(this.info.tag);
			this.element.id = this.id;
			this.element.control = this;
		}
		var node = null;
		var label = null;
		if (this.label) {
			if (this.wrapper == null) {
				this.wrapper = document.createElement('DIV');
				this.wrapper.id = this.id + '#wrapper';
				label = document.createElement('SPAN');
				label.id = this.id + '#label';
				this.label.className = css + 'label';
				label.innerHTML = this.label || this.id;
				this.wrapper.appendChild(label);
				this.wrapper.appendChild(this.element);
			}
			node = this.wrapper;
		} else {
			if (this.wrapper && this.wrapper.parentNode) {
				this.wrapper.parentNode.removeChild(this.wrapper);
			}
			node = this.element;
		}
		var css = this.css.join(' ');
		if (this.css.length > 0) {
			this.element.className = css;
			css += ' ';
		}
		if (this.wrapper != null) {
			this.wrapper.className = css + 'wrapper';
			label.className = css + 'label';
		}

		if (node.parentNode != ctx.node) {
			ctx.node.appendChild(node);
		}
	};

	Ui.Control.registerHandler = function(ctrl, event, handler, context) {
		context = context || window;
		if (ctrl.handlers[event] == undefined) ctrl.handlers[event] = [];
		ctrl.handlers[event].push({fn: handler, obj: context});
	};
	Ui.Control.create = function(id, template, el) {
		var info = Ui.Control.Types[template.type];
		if (info === undefined) throw new Error('Unsupported Control type ('+template.type+')!');
		var ctrl = Reflect.construct(info.ctor, [id, template, el]);
		return ctrl;
	};
	Ui.Control.DataTypes = {
		int:	'int',
		float:  'float',
		string: 'string'
	};

	Ui.Control.Types = {};

	Ui.Control.onevent = function(e) {
		var event = e.type;
		var control = e.target.control;
		var handlers = control.handlers[event];
		if (handlers != undefined) {
			for (var i=0; i<handlers.length; i++) {
				var handler = handlers[i];
				handler.fn.call(handler.obj, control);
			}
		}
	};

	addToSearchPath();
	public(Ui, 'Ui');
})();