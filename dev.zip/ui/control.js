(function() {
	var Ui = {};
	Ui.Control = function(id, template, el) {
		this.id = id;
		this.info = Ui.Control.Types[template.type];
		this.css = [];
		this.handlers = {};
		this.constructor = Ui.Control;
	}
	//Ui.Control.prototype.bind = function(obj) { throw new Error('Not implemented!'); };
	Ui.Control.prototype.getValue = function() { return this.element.value; };
	Ui.Control.prototype.setValue = function(v) { this.element.value = v; };
	Ui.Control.prototype.render = function(ctx) {
		if (this.element === undefined) {
			this.element = document.createElement(this.info.tag);
			this.element.id = this.id;
			this.element.control = this;
		}
		if (this.parentNode && this.parentNode != ctx.node) {
			this.parentNode.removeChild(this.element);
			ctx.node.appendChild(this.element);
		}
		this.element.className = this.css.join(' ');
	};

	Ui.Control.registerHandler = function(ctrl, event, handler, context) {
		context = context || window;
		if (ctrl.handlers[event] == undefined) ctrl.handlers[event] = [];
		ctrl.handlers[event].push({fn: handler, obj: context});
	};
	Ui.Control.create = function(id, template, el) {
		var info = Ui.Control.Types[template.type];
		if (info === undefined) throw new Error('Unsupported Control type ('+config.type+')!');
		var ctrl = Reflect.construct(info.ctor, [id, template, el]);
		return ctrl;
	};
	Ui.Control.DataTypes = {
		int:	'int',
		float:  'float',
		string: 'string'
	};

	Ui.Control.Types = {};

	Ui.Control.onevent = function(e) {
		var event = e.type;
		var control = e.target.control;
		var handlers = control.handlers[event];
		if (handlers != undefined) {
			for (var i=0; i<handlers.length; i++) {
				var handler = handlers[i];
				handler.fn.call(handler.obj, control);
			}
		}
	};

	addToSearchPath();
	public(Ui, 'Ui');
})();