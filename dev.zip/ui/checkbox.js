include('/ui/valuecontrol.js');

(function() {
	Ui.Checkbox = function(id, config, el) {
		Ui.ValueControl.call(this, id, config, el);
	}
	Ui.Checkbox.base = Ui.ValueControl.prototype;
	Ui.Checkbox.prototype = new Ui.ValueControl('checkbox');
	Ui.Control.Types['checkbox'] = { ctor: Ui.Checkbox, tag: 'INPUT' };
	Ui.Checkbox.prototype.render = function(ctx) {
    	Ui.Checkbox.base.render.call(this, ctx);
	    this.element.setAttribute('type', 'checkbox');
		this.element.checked = this.value == true;
    };

})();