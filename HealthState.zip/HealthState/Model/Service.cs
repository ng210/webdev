﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HealthState.Model
{
    public class Service
    {
        public string Id;
        public string Name;
        public int Port;
        public bool State;
    }
}
