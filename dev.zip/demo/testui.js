include('demo.js');
(function() {
    function TestUi(canvas) {
        this.id = 'Test-UI';
        this.canvas = canvas;
        this.config = {};
        this.constructor = TestUi;
    }
    TestUi.prototype = new Demo();
    TestUi.prototype.initialize = function() {
		Dbg.prln('TestUi initialize');
        var grid = this.ui.persons;
		// custom init of color ddlist
        var col = grid.columns['color'];
        col.cells.forEach(ddl => ddl.setItems(this.config.colors));
    col.cells.forEach(ddl => Dbg.prln(ddl.id));
        //this.ui.color.setItems(['red', 'green', 'blue', 'black', 'white']);
	};
    TestUi.prototype.processInputs = function() { throw new Error('Not implemented'); };
    TestUi.prototype.update = function(frame) {
    };
    TestUi.prototype.render = function(frame) {
    };
    
    TestUi.prototype.onchange = function(ctrl) {
        Dbg.prln('TestUi.onchange at ' + ctrl.id);
    };
    TestUi.prototype.onclick = function(ctrl) {
        Dbg.prln('TestUi.onclick at ' + ctrl.id);
    };

    public(TestUi, 'TestUi');

})();