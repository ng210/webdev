(function() {
	var Ui = {};
	Ui.Control = function(id, template) {
		this.id = id || 'control';
		this.template = template || {type:'none'};
		this.label = '';
		if (typeof this.template.label === 'string') this.label = this.template.label;
		this.css = [];
		this.handlers = {};
		this.info = Ui.Control.Types[this.template.type];
		if (Array.isArray(this.template.events)) {
			for (var i=0; i<this.template.events.length; i++) {
				this.registerHandler(this.template.events[i], this);
			}
		}
		this.element = null;
		this.wrapper = null;
		this.constructor = Ui.Control;
	}

	Ui.Control.prototype.dataBind = function(obj, field) { this.dataSource = obj; if (field !== undefined) this.dataField = field; };
	Ui.Control.prototype.getValue = function() { return this.element.value; };
	Ui.Control.prototype.setValue = function(v) { this.element.value = v; };
	Ui.Control.prototype.render = function(ctx) {
		if (!this.element) {
			this.element = document.createElement(this.info.tag);
			this.element.id = this.id;
			this.element.control = this;
		}
		var node = null;
		var label = null;
		if (this.label) {
			if (this.wrapper == null) {
				this.wrapper = document.createElement('DIV');
				this.wrapper.id = this.id + '#wrapper';
				label = document.createElement('SPAN');
				label.id = this.id + '#label';
				this.label.className = css + 'label';
				label.innerHTML = this.label;
				this.wrapper.appendChild(label);
				this.wrapper.appendChild(this.element);
			}
			label = this.wrapper.childNodes[0];
			node = this.wrapper;
		} else {
			if (this.wrapper && this.wrapper.parentNode) {
				this.wrapper.parentNode.removeChild(this.wrapper);
			}
			node = this.element;
		}
		var css = this.css.join(' ');
		if (this.css.length > 0) {
			this.element.className = css;
			css += ' ';
		}
		if (this.wrapper != null) {
			this.wrapper.className = css + 'wrapper';
			label.className = css + 'label';
		}

		for (eventName in this.handlers) {
			if (this.element.addEventListener) {
				this.element.removeEventListener(eventName, Ui.Control.onevent);
				this.element.addEventListener(eventName, Ui.Control.onevent);
			} else if (this.element.attachEvent) {
				this.element.detachEvent(eventName, Ui.Control.onevent);
				this.element.attachEvent(eventName, Ui.Control.onevent);
			}
		}

		if (node.parentNode != ctx.node) {
			ctx.node.appendChild(node);
		}
	};
	Ui.Control.registerHandler = function(eventName, context) {
		context = context || window;
		var handler = context['on'+eventName];
		if (typeof handler === 'function') {
			if (this.handlers[eventName] === undefined) {
				this.handlers[eventName] = [];
			}
			this.handlers[eventName].push({fn: handler, obj: context});
			Dbg.prln('register ' + eventName + ' for ' + context.id);
		}
	};
	// Statics
	Ui.Control.DataTypes = {
		int:	'int',
		float:  'float',
		string: 'string'
	};
	Ui.Control.Types = {};
	Ui.Control.create = function(id, template, el) {
		var info = Ui.Control.Types[template.type];
		if (info === undefined) throw new Error('Unsupported Control type ('+template.type+')!');
		var ctrl = Reflect.construct(info.ctor, [id, template, el]);
		return ctrl;
	};
	Ui.Control.onevent = function(e) {
		var event = e.type;
		var control = e.target.control;
		var handlers = control.handlers[event];
Dbg.prln(event);
		if (handlers != undefined) {
			for (var i=0; i<handlers.length; i++) {
				var handler = handlers[i];
				handler.fn.call(handler.obj, control);
			}
		}
	};

	addToSearchPath();
	public(Ui, 'Ui');
})();