include('demo.js');
(function() {
    function TestUi(canvas) {
        this.id = 'Test-UI';
        this.canvas = canvas;
        this.config = {};
        this.constructor = TestUi;
    }
    TestUi.prototype = new Demo();
    TestUi.prototype.initialize = function() { Dbg.prln('TestUi initialize'); };
    TestUi.prototype.processInputs = function() { throw new Error('Not implemented'); };
    TestUi.prototype.update = function(frame) {
    };
    TestUi.prototype.render = function(frame) {
    };
    
    public(TestUi, 'TestUi');

})();