include('/ui/valuecontrol.js');

(function() {
	Ui.Slider = function(id, config, el) {
		Ui.ValueControl.call(this, id, config, el);
		el.setAttribute('type', 'range');
	};
	Ui.Slider.prototype = new Ui.ValueControl('slider', {}, {});
	Ui.Control.Types['slider'] = { ctor: Ui.Slider, tag: 'INPUT' };

})();