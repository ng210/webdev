include('control.js');

(function() {
    // Abstract class for multi-value controls
    Ui.ListControl = function(id, config, el) {
        Ui.Control.call(this, id, el);
        this.items = [];
        if (Array.isArray(config.items)) {
            for (var i=0; i<config.items.length; i++)	{
                var configItem = config.items[i];
                var item = {};
                var option = document.createElement("option");
                if (Array.isArray(config.items[i])) {
                    item.key = configItem[0];
                    item.value = configItem[1];						
                } else {
                    item.key = item.value = configItem;
                }
                item.index = i;
                option.text = item.key;
                option.value = item.value;
                this.element.add(option);
                this.items.push(item);
            }
        }
        this.setValue(config.value);
        el.onchange = Ui.Control.onevent;

    };
    Ui.ListControl.prototype = new Ui.Control('listCtrl', {}, {});

})();
