include('/ui/valuecontrol.js');

(function() {
	Ui.Button = function(id, template, el) {
		Ui.ValueControl.call(this, id, template, el);
	};
	Ui.Button.prototype = new Ui.ValueControl('button', {}, {});
	Ui.Control.Types['button'] = { ctor: Ui.Button, tag: 'INPUT' };

	Ui.Button.prototype.render = function(ctx) {
    	Ui.ValueControl.prototype.render.call(this, ctx);
	    this.element.setAttribute('type', 'button');
    };
})();