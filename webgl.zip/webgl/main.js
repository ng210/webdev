include('dbg.js');
include('ge.js');
include('v3.js');
include('m4.js');
//include('webgl.js');

var gl = null;
var vertices = [];
var vbo = null;
var prg = null;
var pt = [];
var count = 10000;
var eye = new V3(0, 0, -2.3);
var width = 400;
var height = 300;
var globalColor = [.5, .7, .9, 1.0];
var vertexDataCount = 3;

function createSphere(an, a1, a2, dn, d1, d2) {
	var v = [];
	var astep = 360/an, dstep = 360/dn;
	for (var ai=a1; ai<a2; ai+=astep) {
		var ar = Math.PI/180*ai;
		var acos = Math.cos(ar), asin = Math.sin(ar);
		for (var di=d1; di<d2; di+=dstep) {
			var dr = Math.PI/180*di;
			var dcos = Math.cos(dr), dsin = Math.sin(dr);
			var x = acos*dcos;
			var y = dsin;
			var z = asin*dcos;
			v.push(x, y, z);
		}
	}
	return Float32Array.from(v);
}

function reset(pt, stop) {
	var id = pt.id;
	var ix = id*vertexDataCount;
	var v = null;
	var pos = new V3();

	if (!stop) {
		pt.m = 1;
		// create coordinates
		var le = (count-id)/count;
		pos = V3.fromPolar(
			2*Math.PI*Math.random(),
			2*Math.PI*Math.random(),
			1// - Math.pow(le, 4)*Math.random()
		);
		//pos = new V3(2*Math.random()-1, 2*Math.random()-1, 2*Math.random()-1);
		// create velocity vectors
		v = V3.fromPolar(
			2*Math.PI*Math.random(),
			2*Math.PI*Math.random(),
			Math.random()*0.2
		);
	} else {
		pt.m = 0;
		v = new V3();
	}
	// var o = new V3(-.5, -.5, -.5);
	// pos.inc(o).scale(2.0);
	vertices[ix+0]=pos.x;
	vertices[ix+1]=pos.y;
	vertices[ix+2]=pos.z;
	vertices[ix+3]=v.x;
	vertices[ix+4]=v.y;
	vertices[ix+5]=v.z;

	// create acceleration vector?
}

function prepareScene() {
/*
	vertices = new Float32Array(4*vertexDataCount*count);
	for (var i=0; i<count; i++) {
		var p1 = {m:1, id:i};
		pt.push(p1);
		reset(p1);
	}
*/
	vertices = createSphere(18, 0, 360, 18, 0, 360);
	count = vertices.length/3;
	for (var i=0; i<3*count;) {
		Dbg.prln(vertices[i++].toFixed(4)+','+vertices[i++].toFixed(4)+','+vertices[i++].toFixed(4));
	}
	vbo = gl.createBuffer();
	updateVBO();

	var shaders = load([
		{ 'url':'v1.glsl', 'contentType':'x-shader/x-vertex' },
		{ 'url':'f1.glsl', 'contentType':'x-shader/x-fragment' },
	]);
	shaders.forEach(s => { if (s instanceof Error) throw s;});

	prg = webGL.createProgram(gl,
		shaders,
		{
			'aPos': { 'type':gl.FLOAT, 'size':3 }
			//,'aV1': { 'type':gl.FLOAT, 'size':3 }
		},
		{
			'uGlobalColor': { 'type':webGL.FLOAT4V },
			'uProjection': { 'type': webGL.FLOAT4x4M },
			'uModelView': { 'type': webGL.FLOAT4x4M },
			'uDTime': { 'type':webGL.FLOAT },
			'uLightDir': { 'type':webGL.FLOAT4V }
		}
	);
}

function updateVBO() {
	gl.bindBuffer(gl.ARRAY_BUFFER, vbo);
	gl.bufferData(gl.ARRAY_BUFFER, vertices, gl.STATIC_DRAW);
	gl.bindBuffer(gl.ARRAY_BUFFER, null);
}

function render(fm) {
	//Dbg.prln('render '+fm);
	gl.clearColor(0.0, 0.1, 0.2, 1.0);
	gl.clearDepth(1.0);
	gl.enable(gl.DEPTH_TEST);
	gl.depthFunc(gl.LEQUAL);
	gl.enable(gl.BLEND);
	gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
	gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

	var projection = M4.perspective(60*Math.PI/180, width/height, 0.01, 100.0).data;
	var dtime = fm*0.01;
	var modelView = M4.lookAt(eye, new V3(0, 0, 0), new V3(0, 1, 0)).data;

	var lightDir = [GE.inputs.mpos[0]/width, 1-GE.inputs.mpos[1]/height, 0.0, 1.0];

	gl.bindBuffer(gl.ARRAY_BUFFER, vbo);
	webGL.useProgram(gl, prg, {
		'uGlobalColor': globalColor,
		'uProjection': projection,
		'uModelView': modelView,
		'uDTime': dtime,
		'uLightDir': lightDir
	});

	gl.drawArrays(gl.POINTS, 0, count);
	gl.bindBuffer(gl.ARRAY_BUFFER, null);
}

function processInputs() {
	var arrows = GE.readArrows();
	if (arrows[0] != 0) {
		eye.x -= arrows[0]*0.01;
		//Dbg.prln('arr-x: ' + arrows[0]);
	}
	if (arrows[1] != 0) {
		eye.z -= arrows[1]*0.01;
		//Dbg.prln('arr-y: ' + arrows[1]);
	}
}

(function() {
	const _HASHLENGTH = 8;
	var _HASHBASE = 1638278921;

	function getHash() {
		var hash = [];
		for (var i=0; i<_HASHLENGTH; i++) {
			var s = (_HASHBASE % 255).toString(16);
			hash.push(s.length == 2 ? s : '0'+s);
			_HASHBASE = 217*_HASHBASE + 19587;
		}
		return hash.join('');
	}

    if (Object.prototype.getHash === undefined) {
		Object.defineProperty(Object.prototype, "getHash", {
			value: () => getHash(),
			enumerable: false,
			writable: false
		});
    }
})();

window.onload = () => {
	try {
		Dbg.init('con');
		GE.init('cvs');

		//Dbg.prln(load.normalizePath('/dir1/dir2/file.txt', '/root')+' : /dir1/dir2/file.txt');
		//Dbg.prln(load.normalizePath('dir1/dir2/file.txt', '/root')+' : /root/dir1/dir2/file.txt');
		//Dbg.prln(load.normalizePath('file.txt', '/root')+' : /root/file.txt');
		//Dbg.prln('Base URL: ' + baseUrl);
		//var url = new Url(load.normalizePath('/dir1/dir2/file.txt'));
		//Dbg.prln('URL: ' + url);
		//Dbg.prln(url + ' : http://localhost:80/dir1/dir2/file.txt');
		//Dbg.prln(new Url(load.normalizePath('dir1/dir2/file.txt'))+' : http://localhost:80/webgl/root/dir1/dir2/file.txt');
		//Dbg.prln(new Url(load.normalizePath('file.txt'))+' : http://localhost:80/webgl/file.txt');

		Dbg.prln('Dbg....... #' + Dbg.getHash());
		Dbg.prln('GE........ #' + GE.getHash());
		Object.keys(Dbg).forEach( k => { Dbg.pr(k+'..........'.slice(k.length) + ' #'); Dbg.prln(Dbg[k].getHash())});

var modelView = M4.lookAt(eye, new V3(0, 0, 0), new V3(0, 1, 0));
var vt = modelView.vMul([0.0, 0.0, -1.0, 1.0]);
Dbg.prln('-1.0: ' + vt[2]/vt[3]);
vt = modelView.vMul([0.0, 0.0, 1.0, 1.0]);
Dbg.prln(' 1.0: ' + vt[2]/vt[3]);
		Dbg.prln('start...');
		var cvs = document.querySelector('#cvs');
		var cnt = document.querySelector('#cvs-container');
		width = cvs.width = cnt.clientWidth;
		height = cvs.height = cnt.clientHeight;
		con.style.width = '0px';
		con.style.width = (width - con.offsetWidth) + 'px';
		gl = webGL.init(cvs);

		if (gl == null) throw new Error('webGL not supported!');
		prepareScene();
		GE.processInputs = processInputs;
		//GE.update = update;
		GE.render = render;
		GE.start();

	} catch (error) {
		Dbg.prln(error.message);
		Dbg.prln(error.stack);
	}
};
