include('model.js');

function Sphere(an, a2, dn, d1, d2, flags, xform) {
    var v = [];
    var ix = [];
    if (typeof(xform) !== 'function') {
    	xform = (x, y, z) => [x, y, z];
	} 
    dn = dn/2;
    var di1 = Math.floor(d1*dn);
    var di2 = Math.floor(d2*dn);
    var din = di2 - di1;
    var vn = 0;
    var i0 = 0;
    for (var di=di1; di<=di2; di++) {
        var dr = Math.PI*(di/dn);
        var dc = Math.cos(dr);
        var ds = Math.sin(dr);
        var r = Math.abs(ds);
        var ain = 0;
        var ai2 = Math.floor(a2*an);
        for (var ai=0; ai<ai2; ai++) {
            var ar = 2*Math.PI*(ai/an);
            var ac = Math.cos(ar)
            var as = Math.sin(ar);
            if (ai == 0 || di > 0 && di < dn) {
                if ((flags & webGL.VERTEX_ATTRIB_POSITION) != 0) {
                	var v3 = xform(ac*r, dc, as*r);
                    v.push(v3[0], v3[1], v3[2]);
                }
                if ((flags & webGL.VERTEX_ATTRIB_NORMAL) != 0) {
                    var nv = new V3(ac*r, dc, as*r).norm();
                    v.push(nv.x, nv.y, nv.z);
                }
                vn++;
            }
            if (!(di < 1 || ai == ai2-1 && ai2 != an)) {
                var i1 = i0 + ain;
                var i2 = i0 + (ain+1)%an;
                var i3 = i1 - ai2;
                var i4 = i2 - ai2;
                if (di == 1) {
                    ix.push(0, i1, i2);
                } else if (di < dn) {
                    ix.push(i3, i1, i2);
                    ix.push(i3, i2, i4);
                } else if (di == dn) {
                    ix.push(i1, vn-1, i2);
                }
            }
            ain++;
        }
        if (di < dn-1)
            i0 = vn;
    }
    Model.call(this, 'Sphere', Float32Array.from(v), Int16Array.from(ix), flags);
    this.scale = [1.0, 1.0, 1.0];
    this.color = Float32Array.from([1.0, 1.0, 1.0, 1.0]);
    this.position = new Float32Array(4);
}
Sphere.prototype = new Model;

Sphere.prototype.getUniforms = function(uniforms) {
    var dt = uniforms['frame'] * 0.03;
    uniforms['uGlobalColor'] = this.color;
    var scale = M4.scaleV(this.scale);
    var rot = M4.rotate(this.config.axis, dt*2*Math.PI/this.config.period);
    uniforms['uModel'] = scale.mul(M4.translateV(this.config.position)).mul(rot).data;
};

Sphere.prototype.getUniformsOrbit = function(uniforms) {
    var dt = uniforms['frame'] * 0.03;
    uniforms['uGlobalColor'] = this.color;
    var scale = M4.scaleV(this.scale);
    var rot = M4.rotate(this.config.axis, dt*2*Math.PI/this.config.period);
    var r = this.config.radius;
    this.position = rot.mulV([0, r, 0, 1.0]);
    uniforms['uModel'] = scale.mul(M4.translateV(this.position)).data;
    uniforms['uLightPos'] = this.position;
};