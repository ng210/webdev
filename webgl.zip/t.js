var bv1 = new V3(1.0, 2.0, 3.0);
		var bv2 = new V3(3.0, 2.0, 1.0);
		Dbg.prln(bv1.add(bv2));
		Dbg.prln(bv1.inc(bv2));
		Dbg.prln(bv1.scale(2.0));
		Dbg.prln(bv1);
		return;

		//Dbg.prln(load.normalizePath('/dir1/dir2/file.txt', '/root')+' : /dir1/dir2/file.txt');
		//Dbg.prln(load.normalizePath('dir1/dir2/file.txt', '/root')+' : /root/dir1/dir2/file.txt');
		//Dbg.prln(load.normalizePath('file.txt', '/root')+' : /root/file.txt');
		//Dbg.prln('Base URL: ' + baseUrl);
		//var url = new Url(load.normalizePath('/dir1/dir2/file.txt'));
		//Dbg.prln('URL: ' + url);
		//Dbg.prln(url + ' : http://localhost:80/dir1/dir2/file.txt');
		//Dbg.prln(new Url(load.normalizePath('dir1/dir2/file.txt'))+' : http://localhost:80/webgl/root/dir1/dir2/file.txt');
		//Dbg.prln(new Url(load.normalizePath('file.txt'))+' : http://localhost:80/webgl/file.txt');

		//Dbg.prln('Dbg....... #' + Dbg.getHash());
		//Dbg.prln('GE........ #' + GE.getHash());
		//Object.keys(Dbg).forEach( k => { Dbg.pr(k+'..........'.slice(k.length) + ' #'); Dbg.prln(Dbg[k].getHash())});
