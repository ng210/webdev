include('ge/fn.js');
(function() {

	function Dot() {
		this.reset();
		this.constructor = Dot;
	}
	Dot.prototype.reset = function(span) {
		this.pos = [2*Math.random()-1, 2*Math.random()-1];
		this.span = 0;
		this.spanMax = span * (1 + Math.random())/2;
		this.r = 0.001
		this.mass = Dot.mass(this.r);
		var arg = 2 * Math.PI * Math.random();
		var r = 0;	//0.0001*Math.random();
		var vx = r*Math.cos(arg), vy = r*Math.sin(arg);
		this.v = [vx, vy];
		this.a = [0.0, 0.0];
		this.isAlive = true;
	};
	Dot.prototype.update = function(frame, dt) {
		this.pos[0] += this.v[0]*dt;
		this.pos[1] += this.v[1]*dt;
		this.v[0] += this.a[0]*dt;
		this.v[1] += this.a[1]*dt;
		this.a[0] = 0;
		this.a[1] = 0;
		this.span += dt/1000;
		return this.span < this.spanMax;
	};
	Dot.radiusFactor = (function(){ return Math.pow(6, 0.2); })();
	Dot.prototype.render = function(frame, ctx) {
		// a*x^5 = 1 => x^5 = 1/a => x = pow(1/a, 1/5) = pow(a, -1/5)
		var r = ctx.canvas.width*this.r;
		var x = (this.pos[0] + 1.0) * ctx.canvas.width/2;
		var y = (this.pos[1] + 1.0) * ctx.canvas.height/2;
		var alpha = 1.0;
		var sr = this.span/this.spanMax;
		if (sr < 0.2) {
			alpha = Fn.smoothstep(5*sr, 0.0, 1.0);
		} else {
			if (sr > 0.8) {
				alpha = Fn.smoothstep(5 - 5*sr, 0.0, 1.0)
			}
		}
		for (var i=4; i>=0; i--) {
			ctx.beginPath();
			ctx.fillStyle = 'rgba(255,210,60,' + alpha + ')';
			ctx.arc(x, y, r, 0, 2*Math.PI);
			alpha *= 0.4;
			r = r * Dot.radiusFactor;
			ctx.fill();
		}
		//ctx.fillRect(x, y, s, s);
	};
	Dot.prototype.toString = function() {
		return [
			'mass:     ' + (1000*this.mass).toFixed(4),
			'radius:   ' + this.r.toFixed(4),
			'position: ' + this.pos[0].toFixed(4)+' | '+this.pos[1].toFixed(4)
		].join();
	};
	
	Dot.radius = function(m) {
		return Math.pow(3*m/4/Math.PI, 1/3);
	};
	Dot.mass = function(r) {
		return 4*r*r*r*Math.PI/3;
	};
	
	public(Dot, 'Dot');

})();