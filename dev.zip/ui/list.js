include('/ui/control.js');

(function() {
    // Abstract class for row/column containers of multiple controls
    Ui.List = function(id, config, el) {
        Ui.Control.call(this, id, el);
        this.config = config;
        this.items = [];
        this.orientation = Ui.List.orientation[config.orientation.toUpperCase()] || Ui.List.orientation.VERTICAL;
        this.templates = config.templates;
        this.templateSelector = config['template-selector'] || 'template';
        this.dataSource = config['data-source'] || [];
        // todo
        this.render(el);
        this.constructor = Ui.List;
    };
    Ui.List.prototype = new Ui.Control('listCtrl', {}, {});
    Ui.List.orientation = { HORIZONTAL: 1, VERTICAL: 2 };
    Ui.Control.Types['list'] = { ctor: Ui.List, tag: 'DIV' };

    Ui.List.prototype.render = function(el) {
        this.el = el === undefined ?  document.createElement('DIV') : el;
        var table = document.createElement('TABLE');
        var tr = document.createElement('TR');
        for (var i=0; i<this.dataSource.length; i++) {
            var item = this.dataSource[i];
            var templateName = item[this.templateSelector];
            var template = this.templates[templateName];
            if (template === undefined) throw new Error('Invalid template "' + templateName + '"!');
            var td = document.createElement('TD');
            template.dataSource = item;
            var ctrl = Ui.Control.create(this.id+'#'+i+'#'+templateName, template);
            this.items[i] = ctrl;
            td.appendChild(ctrl.element);
            tr.appendChild(td);
            if (this.orientation === Ui.List.orientation.VERTICAL) {
                table.appendChild(tr);
                tr = document.createElement('TR');
            }
        }
        if (this.orientation !== Ui.List.orientation.VERTICAL) {
            table.appendChild(tr);
        }
        this.el.appendChild(table);
    };
alert(1);
})();
