include('/ui/valuecontrol.js');

(function() {
	Ui.Textbox = function(id, config, el) {
		Ui.ValueControl.call(this, id, config, el);
		el.setAttribute('type', 'text');
		this.element.setAttribute('size', config.size || 4);
		this.constructor = Ui.Textbox;
	};
	Ui.Textbox.prototype = new Ui.ValueControl('textbox', {}, {});
	Ui.Control.Types['textbox'] = { ctor: Ui.Textbox, tag: 'INPUT' };
	Ui.Textbox.prototype.registerHandler = function(event, handler, context) {
		if (['change', 'key'].indexOf(event) == -1) throw new Error('Event \''+ event +'\' not supported!');
		new Ui.Control.registerHandler(this, event, handler, context);
    };

})();