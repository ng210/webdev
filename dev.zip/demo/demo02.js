include('demo.js');
include('dot.js');
(function() {
	
    function Demo02(canvas) {
	    Demo.call(this, 'demo02', canvas);
		this.dots = [];
		this.count = 0;
		this.canvas.width = 600;
		this.canvas.height = 400;
		this.lastTime = new Date().getTime();
		this.ctx = canvas.getContext('2d');
        this.constructor = Demo02;
    }
    Demo02.prototype = new Demo;

    Demo02.prototype.initialize = function() {
		this.count = parseInt(this.settings.dots.getValue()) || 50;
		this.settings.dots.setValue(this.count);

		if (this.count < this.dots.length) {
			for (var i=this.count; i<this.dots.length; i++) {
				this.dots[i].span = 0.9*this.dots[i].spanMax;
			}
		} else {
			for (var i=this.dots.length; i<this.count; i++) {
				this.dots.push(new Dot());
			}
		}
		var min = this.count < this.dots.length ? this.count : this.dots.length;
		for (var i=0; i<min; i++) {
			this.dots[i].reset(this.settings.span.getValue());
		}
	};
    Demo02.prototype.processInputs = function() { throw new Error('Not implemented'); };
    Demo02.prototype.resolveCollision = function(a, b, d) {
		if (a.mass < b.mass) {
	    	// swap to make a the heavier one
	    	var c = a; a = b; b = c;
    	}
		b.reset(this.settings.span.getValue());
		// calculate velocity from momentum
		// l = m1*v1 + m2*v2
		// v = l/(m1+m2)
		var lx = a.mass*a.v[0] + b.mass*b.v[0];
		var ly = a.mass*a.v[1] + b.mass*b.v[1];
		a.mass += b.mass;
		a.spanMax += b.spanMax;
		a.r = Dot.radius(a.mass);
		a.v[0] = lx/a.mass; a.v[1] = ly/a.mass;
    };
    Demo02.prototype.update = function(frame) {
		var time = new Date().getTime();
		var timeWarp = parseInt(this.settings.time.getValue());
		var g = parseFloat(this.settings.force.getValue());
		// update position and velocity
		for (var i=0; i<this.count; i++) {
			var dot1 = this.dots[i];
			for (var j=i+1; j<this.count; j++) {
				var dot2 = this.dots[j];
				var dx = dot2.pos[0] - dot1.pos[0], dy = dot2.pos[1] - dot1.pos[1];
// F = f*(m1+m2)/d^2
// a1 = f*m2/d^2*n = f*n/d^2 * m2
// a2 = f*m1/d^2*n = f*n/d^2 * m1
// n = (dx/d, dy/d) = (dx, dy)/d
// f*n/d^2 = f/d^3*(dx, dy)
				var d2 = dx*dx + dy*dy;
				var d = Math.sqrt(d2);
				if (d < 2*(dot1.r + dot2.r)) {
					this.resolveCollision(dot1, dot2, d);
					break;
				}
				var f = g/d/d2;
				dx *= f; dy *= f;
				dot1.a[0] += dot2.mass*dx; dot1.a[1] += dot2.mass*dy;
				dot2.a[0] += -dot1.mass*dx; dot2.a[1] += -dot1.mass*dy;
			}
		}
		for (var i=0; i<this.count; i++) {
			if (!this.dots[i].update(frame, (time - this.lastTime)/timeWarp)) {
				this.dots[i].reset(this.settings.span.getValue());
			}
		}
		this.lastTime = time;
	};
    Demo02.prototype.render = function(frame) {
		this.ctx.fillStyle = '#0e1028';
		this.ctx.fillRect(0, 0, this.ctx.canvas.width, this.ctx.canvas.height);
		this.ctx.fillStyle = '#f0e080';
		//this.ctx.strokeStyle = '#a0e060';
		this.ctx.lineWidth = 2;
	
    	for (var i=0; i<this.count; i++) {
			var dot = this.dots[i];
			dot.render(frame, this.ctx);
    	}
	};
    Demo02.prototype.onresize = function(e) { throw new Error('Not implemented'); };
    Demo02.prototype.onchange = function(setting) {
		var count = parseInt(this.settings.dots.getValue());
		if (isNaN(count) || this.count == count) return;
		for (var i=this.count; i<count; i++) {
			this.dots.push(new Dot());
		}
		this.count = count;
	};

    public(Demo02, 'Demo02');

})();