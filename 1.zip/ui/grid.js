include('control.js');
(function() {
	Ui.Grid = function(id, config, el) {
		Ui.Control.call(this, id, el);
		this.rows = new Array(parseInt(config.rows) || 0);
		this.cols = new Array(parseInt(config.cols) || 0);
		this.dataSource = config.dataSource;
		this.rowTemplates = config['row-templates'];
		this.cellTemplate = config['cell-template'];
		this.render();
		
		this.constructor = Ui.Grid;
	};
	Ui.Grid.prototype = new Ui.Control('grid', {}, {});
	Ui.Control.Types['grid'] = { ctor: Ui.Grid, tag: 'DIV' };
	
	
	Ui.Grid.prototype.addRow = function(ri) {
		var tr = document.createElement('TR');
		tr.className = 'grid row ' + (ri % 2 ? 'even' : 'odd');
		var row = { id: ri, cells: {}, element: tr };
		this.rows[ri] = row;
		this.element.childNodes[0].appendChild(tr);
		return row;
	};
	Ui.Grid.prototype.addCell = function(ri, ci, key, tmpl) {
		var row = this.rows[ri];
		var ctrl = Ui.Control.create(this.id+'#'+ci+'#'+ri, tmpl);
		row.cells[key] = row.cells[ci] = ctrl;
		var td = document.createElement('TD');
		td.className = 'grid cell';
		if (tmpl.label !== false) {
			var label = document.createElement('SPAN');
			label.className = 'grid cell label';
			label.innerHTML = key;
			td.appendChild(label);
		}
		td.appendChild(ctrl.element);
		tr.appendChild(td);
		return ctrl;
	};
	Ui.Grid.prototype.render = function() {
		var table = document.createElement('TABLE');
		table.className = 'grid table';
		this.element.appendChild(table);
		if (this.rowTemplates !== undefined) {
			for (var ri=0; ri<this.rowTemplates.length; ri++) {
				var tmpl = this.rowTemplates[ri];
				var row = this.addRow(ri);
				//var tr = document.createElement('TR');
				//tr.className = 'grid row ' + (ri % 2 ? 'even' : 'odd');
				//var row = { id: ri, cells: {}, element: tr };
				var cols = Object.keys(tmpl);
				for (var ci=0; ci<cols.length; ci++) {
					var key = cols[ci];
					this.addCell(ri, ci, key, tmpl[key]);
				}
				//this.rows[ri] = row;
				//table.appendChild(tr);
			}
			return;
		}
		if (this.cellTemplate !== undefined) {
			for (var ri=0; ri<this.rows.length; ri++) {
				var tr = document.createElement('TR');
				tr.className = 'grid row ' + (ri % 2 ? 'even' : 'odd');
				var row = { id: ri, cells: new Array(this.cols.length), element: tr };
				for (var ci=0; ci<this.cols.length; ci++) {
					var ctrl = Ui.Control.create(this.id+'#'+ci+'#'+ri, this.cellTemplate);
					ctrl.setValue(this.dataSource[ri][ci]);
					row.cells[ci] = ctrl;
					var td = document.createElement('TD');
					td.className = 'grid cell';
					td.appendChild(ctrl.element);
					tr.appendChild(td);
				}
				this.rows[ri] = row;
				table.appendChild(tr);
			}
			return;
		}
		throw new Error('Invalid or missing template!');
		
/*
		for (var i=0; i<config.rows; i++) {
			var tr = document.createElement('TR');
			tr.className = 'grid row ' + (i % 2 ? 'even' : 'odd');
			var row = { id: i, cells: {}, element: tr };
			for (var j=0; j<config.cols; j++) {
				var td = document.createElement('TD');
				td.className = 'grid cell';
				var ctrl = null;
				if (config.templates.cell !== undefined) {
					ctrl = Ui.Control.create(this.id+'#'+i+'#'+j, config.templates.cell);
					row.cells[key] = row.cells[j] = ctrl;
				} else if (config.templates.row !== undefined) {
					var key = Object.keys(config.templates.row)[j];
					var template = config.templates.row[key];
					ctrl = Ui.Control.create(this.id+'#r'+i+'c'+j, config.templates.row[key]);
					if (template.label !== false) {
						var label = document.createElement('SPAN');
						label.className = 'grid cell label';
						label.innerHTML = key;
						td.appendChild(label);
					}
					row.cells[key] = row.cells[j] = ctrl;
				}
				td.appendChild(ctrl.element);
				tr.appendChild(td);
				if (this.cols[j] === undefined) this.cols.push({ id: j, cells: [] });
				this.cols[j].cells.push(ctrl);
			}
			this.rows.push(row);
			table.appendChild(tr);
		}
*/
		this.element.appendChild(table);
	};
})();