// include('actor.js');
include('webgl.js');

(function() {
	function Model(id, v, ix, fl) {
		this.id = id;
		this.vertexData = v;
		this.indices = ix;
		this.flags = fl;
		this.group = null;
		this.vboOffset = 0;
		this.vboLength = 0;
		this.iboOffset = 0;
		this.iboLength = 0;
		this.constructor = Model;
	}

	// Model.prototype = new Actor;
	Model.prototype.render = function(f) {
		gl.drawElements(gl.TRIANGLES, this.iboLength, gl.UNSIGNED_SHORT, this.iboOffset);
	};
	
	function ModelGroup(id) {
		this.id = id;
		this.vbo = null;
		this.ibo = null;
		this.textures = [];
		this.program = null;
		this.models = [];
		this.constructor = ModelGroup;
	}
	ModelGroup.prototype.add = function(mdl) {
		this.models.push(mdl);
	};
	ModelGroup.prototype.lock = function() {
		// create and merge buffers
		var vertexCount = 0;
		var indexCount = 0;
		for (var mi=0; mi<this.models.length; mi++) {
			var m = this.models[mi];
			m.vboOffset = vertexCount;
			m.iboOffset = indexCount;
			vertexCount += m.vertexData.length;
			indexCount += m.indices.length;
		};
		var vertexData = new Float32Array(vertexCount);
		var indexData = new Int32Array(indexCount);
		var vi = 0, ii = 0;
		for (var mi=0; mi<this.models.length; mi++) {
			var m = this.models[mi];
			for (var i=0; i<m.vertexData.length; i++) {
				vertexData[vi++] = m.vertexData[i];
			}
			for (var i=0; i<m.indices.length; i++) {
				indexData[ii++] = m.indices[i];
			}
		}
		indexData.forEach((x, i) => { Dbg.pr((i%3==0 ? i/3+': ' : '') +  ' ' + x +' '); if (i%3==2) Dbg.pr(' | '); }); Dbg.prln('');
		this.vbo = gl.createBuffer();
		gl.bindBuffer(gl.ARRAY_BUFFER, this.vbo);
		gl.bufferData(gl.ARRAY_BUFFER, vertexData, gl.STATIC_DRAW);
		gl.bindBuffer(gl.ARRAY_BUFFER, null);
		this.ibo = gl.createBuffer();
		gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.ibo);
		gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, indexData, gl.STATIC_DRAW);
		Dbg.prln('ibo: '+gl.getBufferParameter(gl.ELEMENT_ARRAY_BUFFER, gl.BUFFER_SIZE));
		gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, null);
	};
	ModelGroup.prototype.render = function(f) {
		// set gl state
		// set vertex attributes
		// set program
		// set uniforms
		// render models
		this.models.forEach( m => {m.render(f);} );
	};
	
	Model.createSphere = function(an, a2, dn, d1, d2, flags) {
		var v = [];
		var ix = [];
		dn = dn/2;
		var di1 = Math.floor(d1*dn);
		var di2 = Math.floor(d2*dn);
		var din = di2 - di1;
		var vn = 0;
		var i0 = 0;
		for (var di=di1; di<=di2; di++) {
			var dr = Math.PI*(di/dn);
			var dc = Math.cos(dr);
			var ds = Math.sin(dr);
			var r = Math.abs(ds);
			var ain = 0;
			var ai2 = Math.floor(a2*an);
			for (var ai=0; ai<ai2; ai++) {
				var ar = 2*Math.PI*(ai/an);
				var ac = Math.cos(ar)
				var as = Math.sin(ar);
				if (ai == 0 || di > 0 && di < dn) {
					if ((flags & webGL.VERTEX_ATTRIB_POSITION) != 0) {
						v.push(ac*r, dc, as*r);
					}
					if ((flags & webGL.VERTEX_ATTRIB_NORMAL) != 0) {
						var nv = new V3(ac*r, dc, as*r).norm();
						v.push(nv.x, nv.y, nv.z);
					}
					vn++;
				}
				if (!(di < 1 || ai == ai2-1 && ai2 != an)) {
					var i1 = i0 + ain;
					var i2 = i0 + (ain+1)%an;
					var i3 = i1 - ai2;
					var i4 = i2 - ai2;
					if (di == 1) {
						ix.push(0, i1, i2);
					} else if (di < dn) {
						ix.push(i3, i1, i2);
						ix.push(i3, i2, i4);
					} else if (di == dn) {
						ix.push(i1, vn-1, i2);
					}
				}
				ain++;
			}
			if (di < dn-1)
				i0 = vn;
		}

	return new Model('Sphere',
		Float32Array.from(v),
		Int16Array.from(ix),
		flags
	);
}

	public(Model, 'Model');
	public(ModelGroup, 'ModelGroup');

})();