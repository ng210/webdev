include('/ui/valuecontrol.js');

(function() {
	Ui.Checkbox = function(id, config, el) {
		Ui.ValueControl.call(this, id, config, el);
		el.setAttribute('type', 'checkbox');
	};
	Ui.Checkbox.prototype = new Ui.ValueControl('checkbox', {}, {});
	Ui.Control.Types['checkbox'] = { ctor: Ui.Checkbox, tag: 'INPUT' };
    Ui.Checkbox.prototype.getValue = function() { return this.element.checked; };
	Ui.Checkbox.prototype.setValue = function(v) { this.element.checked = v; };

})();