include('/ui/valuecontrol.js');

(function() {
	Ui.Textbox = function(id, template, el) {
		Ui.ValueControl.call(this, id, template, el);
		this.constructor = Ui.Textbox;
	};
	Ui.Textbox.prototype = new Ui.ValueControl('textbox', {}, {});
	Ui.Control.Types['textbox'] = { ctor: Ui.Textbox, tag: 'INPUT' };
	Ui.Textbox.prototype.registerHandler = function(event, handler, context) {
		if (['change', 'key'].indexOf(event) == -1) throw new Error('Event \''+ event +'\' not supported!');
		Ui.Control.registerHandler(this, event, handler, context);
    };
    Ui.Textbox.prototype.render = function(ctx) {
    	Ui.ValueControl.prototype.render.call(this, ctx);
	    this.element.setAttribute('type', 'text');
		this.element.setAttribute('size', this.template.size || 4);
    };

})();