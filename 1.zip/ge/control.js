(function() {
	var Ui = {};
	Ui.Control = function(id, el) {
		this.id = id;
		this.element = el;
		this.element.id = id;
		this.element.className = '';
		this.element.control = this;
	}
	Ui.Control.prototype.bind = function(obj) { throw new Error('Not implemented!'); };
	Ui.Control.prototype.getValue = function() { throw new Error('Not implemented!'); };
	Ui.Control.prototype.setValue = function(v) { throw new Error('Not implemented!'); };
	Ui.Control.create = function(id, config, el) {
		var info = Ui.Control.Types[config.type];
		if (info === undefined) throw new Error('Unsupported Control type!');
		if (el === undefined) el = document.createElement(info.tag);
		var ctrl = Object.create(info.proto, id, config, el);
		return ctrl;
	};
	Ui.Control.DataTypes = {
		int:	'int',
		float:  'float',
		string: 'string'
	};

	Ui.Control.Types = {
		'textbox': { proto: new Ui.Textbox, tag: 'INPUT' },
		'slider':  { proto: new Ui.Slider, tag: 'INPUT' },
		'list': { proto: new Ui.Textbox, tag: 'SELECT' }
	};
	
	// Abstract type for controls holding a single value
	Ui.ValueControl = function(id, config, el) {
		Ui.Control.call(this, id);
		this.isNumeric = false;
		this.parse = null;
		switch (config.dataType) {
			case Ui.Controls.DataTypes.int:
				this.isNumeric = true;
				this.parse = parseInt;
				break;
			case Ui.Controls.DataTypes.float:
				this.isNumeric = true;
				this.parse = parseFloat;
				break;
		}
		if (this.isNumeric) {
			el.setAttribute('min', this.min = this.parse(config.min) || 0);
			el.setAttribute('max', this.max = this.parse(config.max) || 100);
			el.setAttribute('step', this.step = this.parse(config.step) || 1);
			el.value = this.value = this.parse(config.value) || 0);
		} else {
			this.value = config.value;
		}
	}
	Ui.ValueControl.prototype = new Ui.Control;
	Ui.ValueControl.prototype.validate = function() {
		return this.value >= this.min && this.value <= this.max;
	};

	Ui.Textbox = function(id, config, el) {
		Ui.ValueControl.call(this, id, config, el);
		el.setAttribute('type', 'text');
		this.element.setAttribute('size', config.size || 4);
		this.constructor = Ui.Textbox;
	};
	Ui.Textbox.prototype = new Ui.ValueControl;
	
	Ui.Slider = function(id, config, el) {
		Ui.ValueControl.call(this, id, config, el);
		el.setAttribute('type', 'range');
	};
	Ui.Slider.prototype = new Ui.ValueControl;

	Ui.ListControl = function(id, config, el) {
		Ui.Control.call(this, id);
		this.items = [];
		this.element = document.createElement('SELECT');
		for (var i=0; i<config.items.length; i++)	{
			var configItem = config.items[i];
			var item = {};
			var option = document.createElement("option");
			if (Array.isArray(config.items[i])) {
				item.key = configItem[0];
				item.value = configItem[1];						
			} else {
				item.key = item.value = configItem;
			}
			item.index = i;
			option.text = item.key;
			option.value = item.value;
			this.element.add(option);
			this.items.push(item);
		}
		
	};
	Ui.ListControl.prototype = new Ui.Control;

	Ui.DropDownList = function(id, config, el) {
		Ui.ListControl.call(this, id, config, el);
	};
	Ui.DropDownListr.prototype = new Ui.ListControl;
	
			case Control.ControlTypes.list:
				
				break;
		}
		this.element.id = demo.id + '#' + this.id;
		this.element.className = ['settings value', demo.id, this.id, this.control].join(' ');
		this.element.onchange =	Control.onchange;
		this.element.setting = this;

		this.constructor = Control;
	}
	Control.prototype.render = function() {

	};
	Control.prototype.getValue = function()	{
		var	v =	0;
		switch (this.control) {
			default:
			case Control.ControlTypes.slider:
			case Control.ControlTypes.textbox:
				v =	this.element.value;
				break;
			case Control.ControlTypes.list:
				var item = this.items[this.element.selectedIndex];
				v =	{ key: item.key, value: item.value, index:item.index };
				break;
		}
		return v;
	};
	Control.prototype.setValue = function(v) {
		switch (this.control) {
			default:
			case Control.ControlTypes.slider:
			case Control.ControlTypes.textbox:
				this.element.value = v;
				break;
			case Control.ControlTypes.list:
				// set by value
				this.element.selectedIndex = v;
				break;
		}
	};
	
	Control.onchange = function(e) {
		var	setting	= e.target.setting;
		setting.demo.onsettingchanged(setting);
	};
	
	public(Control, 'Control');
})();