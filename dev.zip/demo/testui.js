(function() {
    function TestUi(id, canvas) {
        this.id = id;
        this.canvas = canvas;
        this.config = {};
        this.constructor = TestUi;
    }
    TestUi.prototype.initialize = function() { Dbg.prln('TestUi'); };
    TestUi.prototype.processInputs = function() { throw new Error('Not implemented'); };
    
    public(TestUi, 'TestUi');

})();