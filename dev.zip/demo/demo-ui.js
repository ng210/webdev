include('/ui/textbox.js');
include('/ui/slider.js');
include('/ui/ddlist.js');
include('/ui/checkbox.js');
include('/ui/button.js');
include('/ui/list.js');
include('/ui/grid.js');

(function() {

	var DemoUI = {
		initialize:	function(node, demo) {
			while (node.children.length	> 0) {
				node.removeChild(node.children[0]);
			}
			demo.settings =	{};
			var	tab	= document.createElement('TABLE');
			tab.className =	'settings';
			var	tr = document.createElement('TR');
			var	td = document.createElement('TD');
			td.setAttribute('colspan', 2);
			td.className = 'settings header';
			td.innerHTML = '<b>' + demo.id + '</b>';
			tr.appendChild(td);
			tab.appendChild(tr);
			var	keys = Object.keys(demo.config);
			keys.forEach( key => {
				var config = demo.config[key];
				var	control	= Ui.Control.create(demo.id+'#'+key, config);
				if (Array.isArray(config.events)) {
					for (var ei=0; ei<config.events.length; ei++) {
						var event = config.events[ei];
						var handler = demo['on' + event];
						if (typeof handler === 'function') {
//Dbg.prln('control: ' + control.id + '\nevent: ' + event + '\nhandler: ' + handler);
							control.registerHandler(event, handler, demo);
						}
					}
				}
				demo.settings[key] = control;
				tr = document.createElement('TR');
				td = document.createElement('TD');
				td.className = 'settings value';
				td.appendChild(control.element);
				if (config.type !== 'list' && config.type !== 'grid') {
					var label = document.createElement('TD');
					label.className = 'settings label';
					label.innerHTML = key;
					tr.appendChild(label);
				} else {
					td.setAttribute('colspan', 2);
				}
				tr.appendChild(td);
				tab.appendChild(tr);
			});
			tr = document.createElement('TR');
			td = document.createElement('TD');
			td.setAttribute('colspan', 2);
			td.setAttribute('align', 'center');
			td.className = 'settings value';
			var control = Ui.Control.create(demo.id + '#reset', { 'type':'button', 'value': 'Reset'} );
			control.element.onclick = function(e) { demo.initialize(); };
			td.appendChild(control.element);
			tr.appendChild(td);
			tab.appendChild(tr);
			node.appendChild(tab);
			return settings;
		}
	};

	public(DemoUI, 'DemoUI');
})();