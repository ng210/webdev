include('/ui/control.js');

(function() {
	// Abstract type for controls holding a single value
	Ui.ValueControl = function(id, config, el) {
		Ui.Control.call(this, id, el);
		this.isNumeric = false;
		this.parse = null;
		switch (config.dataType) {
			case Ui.Control.DataTypes.int:
				this.isNumeric = true;
				this.parse = parseInt;
				break;
			case Ui.Control.DataTypes.float:
				this.isNumeric = true;
				this.parse = parseFloat;
				break;
		}
		if (this.isNumeric) {
			el.setAttribute('min', this.min = this.parse(config.min) || 0);
			el.setAttribute('max', this.max = this.parse(config.max) || 100);
			el.setAttribute('step', this.step = this.parse(config.step) || 1);
			this.value = (this.parse(config.value) || 0);
		} else {
			this.value = config.value;
		}
		el.onchange = Ui.Control.onevent;
		el.value = this.value;
	}
	Ui.ValueControl.prototype = new Ui.Control('valueCtrl', {}, {});
	Ui.ValueControl.prototype.validate = function() {
		return this.value >= this.min && this.value <= this.max;
	};
	Ui.ValueControl.prototype.registerHandler = function(event, handler, context) {
		if (['change'].indexOf(event) == -1) throw new Error('Event \''+ event +'\' not supported!');
		Ui.Control.registerHandler(this, event, handler, context);
	};

})();