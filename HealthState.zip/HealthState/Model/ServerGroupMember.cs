﻿namespace HealthState.Model
{
    public class ServerGroupMember
    {
        public string Id;
    }
}