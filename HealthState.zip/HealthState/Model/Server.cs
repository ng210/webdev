﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HealthState.Model
{
    public class Server : ServerGroupMember
    {
        public string Path;
        public List<Service> Services;
    }
}
