include('control.js');
// row/column based => list
// template for rows/cells selected by an optional data field
(function() {
	Ui.Grid = function(id, template) {
		Ui.Control.call(this, id, template);
		// set rows/columns array
		this.rows_ = [];
		this.rows = {}:
		this.columns_ = [];
		this columns = {};
		this.rowTemplates = template['row-templates'] || {};
		this.cellTemplate = template['cell-template'] || {};
		this.templateSelector = template['template-selector'];
		this.dataSource = null;
		//this.dataMapping = template['data-mapping'] || [];

		this.constructor = Ui.Grid;
	};
	Ui.Grid.base = Ui.Control.prototype;
	Ui.Grid.prototype = new Ui.Control('grid');
	Ui.Control.Types['grid'] = { ctor: Ui.Grid, tag: 'DIV' };
/*
	Ui.Grid.prototype.buildRow = function(ri, src) {
		// build a row from the given data source
		// using the selected template
		var row = { id: ri, name: 'row' + ri, cells:{} };
		var tmplKey = src[this.templateSelector] || 'default';
//Dbg.prln('tmplKey: ' + tmplKey);
		var rowTmpl = this.rowTemplates[tmplKey];
		var colKeys = null;
		if (typeof rowTmpl === 'object') {
			colKeys = Object.keys(rowTmpl);
		} else {
			if (Array.isArray(src)) colKeys = src.map( (v, ix) => ix );
			else if (typeof src === 'object') colKeys = Object.keys(src);
			else {
				src = [src];
				colKeys = [0];
			}
		}
//Dbg.prln('colKeys: ' + colKeys);
		for (var ci=0; ci<colKeys.length; ci++) {
			var key = colKeys[ci];
			var col = this.columns_[ci];
			if (col == undefined) {
				col = { id: ci, name: key, cells: [] };
				this.columns[key] = this.columns_[ci] = col;
			}

			var tmpl = rowTmpl[key] ? rowTmpl[key] : this.cellTemplate;
			var dataField = tmpl['data-field'] || key;
			var cell = Ui.Control.create(this.id + '#' + ri + '#' + ci, tmpl);
			if (tmpl.label === true) cell.label = key;
			cell.dataBind(src, dataField);
			cell.row = row; cell.column = col;
			row.cells[ci] = row.cells[key] = cell;
			col.cells.push(cell);
		}
		return row;
	};
	Ui.Grid.prototype.build = function() {
	// create rows, columns and cells
		var src = this.dataSource;
		var rowKeys = null;
		if (Array.isArray(src)) rowKeys = src.map( (v, ix) => ix );
		else if (typeof src === 'object') rowKeys = Object.keys(src);
		else throw new Error('Invalid data source!');
		for (var ri=0; ri<rowKeys.length; ri++) {
			var key = rowKeys[ri];
			var srcRow = this.dataSource[key];
			var row = this.buildRow(ri, srcRow);
			row.name = key;
			this.rows_.push(row);
			this.rows[key] = row;
		}
	};

	Ui.Grid.prototype.dataBind = function(obj) {
		Ui.Grid.base.dataBind.call(this, obj);
		this.build();
	};
	Ui.Grid.prototype.getCell = function(ri, ci) {
		if (typeof ri === 'string') {
			var tokens = ri.split('#');
			ri = tokens[0];
			ci = tokens[1];
		}
		var row = this.rows[ri];
		return row ? row.cells[ci] : null;
	};
*/
/*
	Ui.Grid.prototype.addRow = function(ri) {
		var tr = document.createElement('TR');
		tr.className = 'grid row ' + (ri % 2 ? 'even' : 'odd');
		var row = { id: ri, cells: {}, element: tr };
		this.rows[ri] = row;
		this.element.childNodes[0].appendChild(tr);
		return row;
	};
	Ui.Grid.prototype.addCell = function(row, ci, key, tmpl) {
		var ri = row.id;
		var tr = row.element;
		var ctrl = Ui.Control.create(this.id+'#'+ci+'#'+ri, tmpl);
		var dataField = tmpl['data-field'] || key;
		ctrl.setValue(this.dataSource[dataField]);
		row.cells[key] = row.cells[ci] = ctrl;
		var td = document.createElement('TD');
		td.className = 'grid cell';
		if (tmpl.label !== false) {
			var label = document.createElement('SPAN');
			label.className = 'grid cell label';
			label.innerHTML = key;
			td.appendChild(label);
		}
		td.appendChild(ctrl.element);
		tr.appendChild(td);
		return ctrl;
	};
*/
	Ui.Grid.registerHandler = function(eventName, context, filter) {
		for (var ri=0; ri<this.rows.length; ri++) {
			var row = this.rows[ri];
			for (var ci=0; ci<this.cols.length; ci++) {
				var cell = row.cells[ci];
				if (filter === undefined ||
					typeof filter === 'function' && filter.call(this, cell)) {
					cell.registerHandler(eventName, context);
				}
			}
		}
	};
	Ui.Grid.prototype.render = function(ctx) {
		Ui.Grid.base.render.call(this, ctx);
		var table = document.createElement('TABLE');
		table.className = 'grid table';
		this.element.appendChild(table);
		for (var ri=0; ri<this.rows.length; ri++) {
			var row = this.rows[ri];
			var tr = document.createElement('TR');
			var rowClass = ri % 2 ? 'r0' : 'r1';
			tr.className = 'grid row ' + rowClass;
			for (var ci=0; ci<this.cols.length; ci++) {
				var td = document.createElement('TD');
				var cellClass = rowClass + ' ' + (ci % 2 ? 'c0' : 'c1');
				td.className = 'grid cell ' + cellClass;
				var cell = row.cells[ci];
				cell.render({node: td});
				td.appendChild(cell.element);
				tr.appendChild(td);
			}
			table.appendChild(tr);
		}
	};
})();



/*
var table = document.createElement('TABLE');
		table.className = 'grid table';
		this.element.appendChild(table);
		if (this.rowTemplates !== undefined) {
			for (var ri=0; ri<this.rowTemplates.length; ri++) {
				var tmpl = this.rowTemplates[ri];
				var row = this.addRow(ri);
				//var tr = document.createElement('TR');
				//tr.className = 'grid row ' + (ri % 2 ? 'even' : 'odd');
				//var row = { id: ri, cells: {}, element: tr };
				var cols = Object.keys(tmpl);
				for (var ci=0; ci<cols.length; ci++) {
					var key = cols[ci];
					this.addCell(row, ci, key, tmpl[key]);
				}
				//this.rows[ri] = row;
				//table.appendChild(tr);
			}
			return;
		}
		if (this.cellTemplate !== undefined) {
			for (var ri=0; ri<this.rows.length; ri++) {
				var tr = document.createElement('TR');
				tr.className = 'grid row ' + (ri % 2 ? 'even' : 'odd');
				var row = { id: ri, cells: new Array(this.cols.length), element: tr };
				for (var ci=0; ci<this.cols.length; ci++) {
					var ctrl = Ui.Control.create(this.id+'#'+ci+'#'+ri, this.cellTemplate);
					ctrl.setValue(this.dataSource.rows[ri][ci]);
					row.cells[ci] = ctrl;
					var td = document.createElement('TD');
					td.className = 'grid cell';
					td.appendChild(ctrl.element);
					tr.appendChild(td);
				}
				this.rows[ri] = row;
				table.appendChild(tr);
			}
			return;
		}
		throw new Error('Invalid or missing template!');

		this.element.appendChild(table);
*/