include('demo.js');
include('dot.js');
(function() {
	
    function Demo02(canvas) {
	    Demo.call(this, 'demo02', canvas);
		this.dots = [];
		this.count = 0;
		this.canvas.width = 600;
		this.canvas.height = 400;
		this.lastTime = new Date().getTime();
		this.ctx = canvas.getContext('2d');
        this.constructor = Demo02;
    }
    Demo02.prototype = new Demo;

    Demo02.prototype.initialize = function() {
    	this.count = parseInt(this.settings.dots.getValue()) || 50;
    	// create dots
	    for (var i=0; i<this.count; i++) {
			var dot = new Dot();
			this.dots.push(dot);
			Dbg.prln(dot.toString());
		}
	};
    Demo02.prototype.processInputs = function() { throw new Error('Not implemented'); };
    Demo02.prototype.resolveCollision = function(a, b, d) {
    	var isAlive = a.isAlive;
		if (a.mass < b.mass) {
	    	// swap to make a the heavier one
	    	var c = a; a = b; b = c;
    	}
	    b.isAlive = false;
		// calculate velocity from momentum
		// l = m1*v1 + m2*v2
		// v = l/(m1+m2)
		var lx = a.mass*a.v[0] + b.mass*b.v[0];
		var ly = a.mass*a.v[1] + b.mass*b.v[2];
		a.mass += b.mass;
		a.v[0] = lx/a.mass; a.v[1] = ly/a.mass;
	    return isAlive;
    };
    Demo02.prototype.update = function(frame) {
		var time = new Date().getTime();
		var g = parseFloat(this.settings.force.getValue());
		// update position and velocity
		for (var i=0; i<this.count; i++) {
			var dot1 = this.dots[i];
			if (dot1.isAlive) {
				for (var j=i+1; j<this.count; j++) {
					var dot2 = this.dots[j];
					if (!dot2.isAlive) continue;
					var dx = dot2.pos[0] - dot1.pos[0], dy = dot2.pos[1] - dot1.pos[1];
	// F = f*(m1+m2)/d^2
	// a1 = f*m2/d^2*n = f*n/d^2 * m2
	// a2 = f*m1/d^2*n = f*n/d^2 * m1
	// n = (dx/d, dy/d) = (dx, dy)/d
	// f*n/d^2 = f/d^3*(dx, dy)
					var d2 = dx*dx + dy*dy;
					var d = Math.sqrt(d2);
					if (d < (dot1.r + dot2.r)) {
						ix (this.resolveCollision(dot1, dot2, d)) break;
						continue;
					}
					var f = g/d/d2;
					dx *= f; dy *= f;
					dot1.a[0] += dot2.mass*dx; dot1.a[1] += dot2.mass*dy;
					dot2.a[0] += -dot1.mass*dx; dot2.a[1] += -dot1.mass*dy;
				}
			}
		}
		for (var i=0; i<this.count; i++) {
			this.dots[i].update(frame, (time - this.lastTime)/100);
		}
		this.lastTime = time;
	};
    Demo02.prototype.render = function(frame) {
		this.ctx.fillStyle = '#201040';
		this.ctx.fillRect(0, 0, this.ctx.canvas.width, this.ctx.canvas.height);
		this.ctx.fillStyle = '#a0e060';
		this.ctx.strokeStyle = '#a0e060';
		this.ctx.lineWidth = 2;
	
    	for (var i=0; i<this.count; i++) {
	    	this.dots[i].render(frame, this.ctx);
    	}
	};
    Demo02.prototype.onresize = function(e) { throw new Error('Not implemented'); };
    Demo02.prototype.onsettingchanged = function(setting) {
    	if (setting.id == 'dots') {
	    	var count = parseInt(this.settings.dots.getValue());
			if (isNaN(count) || this.count == count) return;
	    	for (var i=this.count; i<count; i++) {
				this.dots.push(new Dot());
			}
			this.count = count;
    	}
	};

    public(Demo02, 'Demo02');

})();