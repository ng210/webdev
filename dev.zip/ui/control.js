(function() {
	var Ui = {};
	Ui.Control = function(id, template) {
		this.id = id || 'control';
		this.template = template || {type:'none'};
		this.label = '';
		this.dataSource = null;
		this.dataField = this.template['data-field'] || null;
		this.parent = null;
		if (typeof this.template.label === 'string') {
			this.label = this.template.label;
			//this.label = Ui.Control.create('label', {});
			//this.label.setValue(this.template.label);
		}
		this.css = [];
		this.handlers = {};
		Ui.Control.registerHandler.call(this);
		this.info = Ui.Control.Types[this.template.type];
		this.element = null;
		this.labelElem = null;
		this.constructor = Ui.Control;
	}

	Ui.Control.prototype.dataBind = function(obj, field) { this.dataSource = obj; if (field !== undefined) this.dataField = field; };
	Ui.Control.prototype.getValue = function() { return this.value; };
	Ui.Control.prototype.setValue = function(v) { this.value = v; };
	Ui.Control.prototype.render = function(ctx) {
		if (!this.element) {
			this.element = document.createElement(this.info.tag);
			this.element.id = this.id;
			this.element.control = this;
		}
		var css = this.css.join(' ');
		if (this.css.length > 0) {
			this.element.className = css;
			css += ' ';
		}
		if (this.label) {
			if (this.labelElem == null) {
				this.labelElem = document.createElement('SPAN');
				this.labelElem.id = this.id + '#label';
				this.labelElem.className = css + 'label';
				this.labelElem.innerHTML = this.label;
			}
			ctx.node.appendChild(this.labelElem);
		} else {
			if (this.labelElem && this.labelElem.parentNode) {
				this.labelElem.parentNode.removeChild(this.labelElem);
			}
		}

		for (eventName in this.handlers) {
			if (this.element.addEventListener) {
				this.element.removeEventListener(eventName, Ui.Control.onevent);
				this.element.addEventListener(eventName, Ui.Control.onevent);
			} else if (this.element.attachEvent) {
				this.element.detachEvent(eventName, Ui.Control.onevent);
				this.element.attachEvent(eventName, Ui.Control.onevent);
			}
		}

		if (this.element.parentNode != ctx.node) {
			if (this.element.parentNode != null) {
				this.element.parentNode.removeChild(this.element);
			}
			ctx.node.appendChild(this.element);
		}
//Dbg.prln(this.element.parentNode.parentNode.parentNode.tagName);
	};
	Ui.Control.registerHandler = function(eventName, context) {
		if (eventName === undefined) {
			if (Array.isArray(this.template.events)) {
				for (var i=0; i<this.template.events.length; i++) {
					this.registerHandler(this.template.events[i], this);
				}
			}
			return;
		}
		context = context || window;
		var handler;	// = context['on'+eventName];
		var node = this;
		while (handler === undefined && node !== null) {
			handler = node['on'+eventName];
			node = node.parent;
		}
		if (typeof handler === 'function') {
			if (this.handlers[eventName] === undefined) {
				this.handlers[eventName] = [];
			}
			this.handlers[eventName].push({fn: handler, obj: context});
			Dbg.prln('register ' + eventName + ' for ' + context.id);
		}
	};
	// Statics
	Ui.Control.DataTypes = {
		int:	'int',
		float:  'float',
		string: 'string'
	};
	Ui.Control.Types = {};
	Ui.Control.create = function(id, template, el) {
		var info = Ui.Control.Types[template.type];
		if (info === undefined) throw new Error('Unsupported Control type ('+template.type+')!');
		var ctrl = Reflect.construct(info.ctor, [id, template, el]);
		return ctrl;
	};
	Ui.Control.onevent = function(e) {
		var event = e.type;
		var control = e.target.control;
		var handlers = control.handlers[event];
Dbg.prln(event);
		if (handlers != undefined) {
			for (var i=0; i<handlers.length; i++) {
				var handler = handlers[i];
				handler.fn.call(handler.obj, control);
			}
		}
	};

	addToSearchPath();
	public(Ui, 'Ui');
})();