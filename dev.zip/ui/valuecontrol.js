include('/ui/control.js');

(function() {
	// Abstract type for controls holding a single value
	Ui.ValueControl = function(id, template, el) {
		Ui.Control.call(this, id, template, el);
		this.isNumeric = false;
		this.parse = null;
		switch (template['data-type']) {
			case Ui.Control.DataTypes.int:
				this.isNumeric = true;
				this.parse = parseInt;
				break;
			case Ui.Control.DataTypes.float:
				this.isNumeric = true;
				this.parse = parseFloat;
				break;
		}
		if (this.isNumeric) {
			this.min = this.parse(template.min) || 0;
			this.max = this.parse(template.max) || 100;
			this.step = this.parse(template.step) || 1;
		}
		this.dataBind(template['data-source'], template['data-field']);
	}
	Ui.ValueControl.prototype = new Ui.Control('valueCtrl', {}, {});
	Ui.ValueControl.prototype.setValue = function(v) {
		if (this.isNumeric) {
			this.value = this.parse(v) || 0;
		} else {
			this.value = v || '';
		}
	};
	Ui.ValueControl.prototype.dataBind = function(source, field) {
		if (source !== undefined) {
			this.dataSource = source;
		}
		if (field !== undefined) {
			this.dataField = field;
		}
		if (source !== undefined && field !== undefined) {
			// validate?
			this.setValue(this.dataSource[this.dataField]);
		}
	};
	Ui.ValueControl.prototype.validate = function() {
		return this.value >= this.min && this.value <= this.max;
	};
	Ui.ValueControl.prototype.registerHandler = function(event, handler, context) {
		if (['change'].indexOf(event) == -1) throw new Error('Event \''+ event +'\' not supported!');
		Ui.Control.registerHandler(this, event, handler, context);
	};
	Ui.ValueControl.prototype.render = function(ctx) {
		Ui.Control.prototype.render.call(this, ctx);
		if (this.isNumeric) {
			this.element .setAttribute('min', this.min);
			this.element.setAttribute('max', this.max);
			this.element.setAttribute('step', this.step);
		}
		this.element.onchange = Ui.Control.onevent;
		this.element.value = this.value;
	};

})();