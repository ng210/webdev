(function() {
	var Ui = {};
	Ui.Control = function(id, el) {
		this.id = id;
		this.element = el;
		this.element.id = id;
		this.element.className = '';
		this.element.control = this;
		this.handlers = {};
	}
	//Ui.Control.prototype.bind = function(obj) { throw new Error('Not implemented!'); };
	Ui.Control.prototype.getValue = function() { return this.element.value; };
	Ui.Control.prototype.setValue = function(v) { this.element.value = v; };
	Ui.Control.registerHandler = function(ctrl, event, handler, context) {
		context = context || window;
		if (ctrl.handlers[event] == undefined) ctrl.handlers[event] = [];
		ctrl.handlers[event].push({fn: handler, obj: context});
	};
	Ui.Control.create = function(id, config, el) {
		var info = Ui.Control.Types[config.type];
		if (info === undefined) throw new Error('Unsupported Control type ('+config.type+')!');
		if (el === undefined) el = document.createElement(info.tag);
		var ctrl = Reflect.construct(info.ctor, [id, config, el]);
		return ctrl;
	};
	Ui.Control.DataTypes = {
		int:	'int',
		float:  'float',
		string: 'string'
	};

	Ui.Control.Types = {};

	Ui.Control.onevent = function(e) {
		var event = e.type;
		var control = e.target.control;
		var handlers = control.handlers[event];
		if (handlers != undefined) {
			for (var i=0; i<handlers.length; i++) {
				var handler = handlers[i];
				handler.fn.call(handler.obj, control);
			}
		}
	};

	addToSearchPath();
	public(Ui, 'Ui');
})();